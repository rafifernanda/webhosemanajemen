jQuery(document).ready(function($){

	$("select").chosen();

});